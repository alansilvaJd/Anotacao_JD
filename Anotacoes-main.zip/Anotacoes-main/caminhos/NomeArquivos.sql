101 - incluir título
101R - retorno do título incluindo

102 - Alteração Título
102R -Retorno da alteração do título

108 - Baixa do título
108R- Retorno da baixa do título.

116  - Cancelamento
116R - Retorno Cancelamento 
